---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 充能赛特斯石英水晶
  icon: charged_certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:charged_certus_quartz_crystal
---

# 充能赛特斯石英水晶

<ItemImage id="charged_certus_quartz_crystal" scale="4" />

经过<ItemLink id="charger" />加工的<ItemLink id="certus_quartz_crystal" />。用于制造<ItemLink id="fluix_crystal" />和[赛特斯石英母岩](../items-blocks-machines/budding_certus.md)。

## 配方

<RecipeFor id="charged_certus_quartz_crystal" />
